function F = Mid(y,x,Deta)
global a b d gamma mu
BH = [d*(gamma + exp(x(2)/2 + y(2)/2)) - b*d*(mu + a*exp(x(3)/2 + y(3)/2));
             mu + a*exp(x(3)/2 + y(3)/2) - a*b*d*exp(x(1)/2 + y(1)/2);
        - a*d*exp(x(1)/2 + y(1)/2)*b^2 + gamma + exp(x(2)/2 + y(2)/2)];
F = x + Deta*BH;