%% setting paremeters of the equation %%
a = -0.6; b = -1; c = 0.3;
d = -0.5; gamma = 1; mu = 2;
y0 = [2.0;0.9;1.5];

%% setting attributes of the numerical scheme
T = 1; N = 2^12; 
dt = T/N; M = 1000;
R0 = 2*[1; 2; 4; 8; 16];
Y_t = zeros(3,M,5);
% y_Split = repmat(y0,1,M);
% Y_Split = zeros(3,M,5);
y_Mid = repmat(y0,1,M);   %% 3*M Matrix  
% M sample paths and N small intervals
normal = randn(M,N);
W = sqrt(dt)*normal;
Ah = sqrt(4*abs(log(dt)));
normal(normal>Ah) = Ah; normal(normal<-Ah) = -Ah;
dW = sqrt(dt)*normal;

stepsize = dt + c*dW;  % Midpoint rule
for j = 1:N
    for i = 1:M
        y = y_Mid(:,i)+10; 
        y2 = y_Mid(:,i)+dt; 
        x = y_Mid(:,i);
        while norm(y-y2) > 1e-8
            y = y2;
            BH = [d*(y(1)+x(1))/2*(gamma + (y(2)+x(2))/2) - b*d*(y(1)+x(1))/2*(a*(y(3)+x(3))/2 + mu)
                   (y(2)+x(2))/2*((y(3)+x(3))/2*a + mu) - a*b*d*(y(1)+x(1))*(y(2)+x(2))/4
                    - a*d*(y(1)+x(1))*(y(3)+x(3))*b^2/4 + (y(3)+x(3))/2*(gamma + (y(2)+x(2))/2)];
            y2 = x + stepsize(i,j)*BH;
%             y = y2;
%             y2 = Mid_Phi(y,y_Mid(:,i),stepsize(i,j));
        end
        y_Mid(:,i) = y2;
    end
end

y0 = log(y0);
y_t = repmat(y0,1,M);
for p = 1:5
    y_t = repmat(y0,1,M);
    R = R0(p); 
    Dt = R*dt; 
%     sqrtDt = sqrt(Dt);
    L = N/R;
%     A = sqrt(Dt)*sqrt(4*abs(log(Dt)));
    for j = 1:L
        DetaW = sum(dW(:,(j-1)*R+1:j*R),2);
%         DetaW(DetaW>A) = A; DetaW(DetaW<-A) = -A;
        for i = 1:M
            y5 = y_t(:,i)+10; 
            y6 = y_t(:,i)*(1+Dt);
            while norm(y5-y6)>1e-8
                y5 = y6;
                y = y5; x = y_t(:,i);
                BH = [d*(gamma + exp(x(2)/2 + y(2)/2)) - b*d*(mu + a*exp(x(3)/2 + y(3)/2));
                        mu + a*exp(x(3)/2 + y(3)/2) - a*b*d*exp(x(1)/2 + y(1)/2);
                     - a*d*exp(x(1)/2 + y(1)/2)*b^2 + gamma + exp(x(2)/2 + y(2)/2)];
                y6 = x + (Dt+c*DetaW(i))*BH;
                %
                % Mid(y5,y_t(:,i),Dt+c*DetaW(i));
            end
            y_t(:,i) = y6;
        end
    end
    Y_t(:,:,p) = exp(y_t);
end

D_t = zeros(M,5);

for p = 1:5
    for j = 1:M
        D_t(j,p) = norm(Y_t(:,j,p) - y_Mid(:,j));
    end
end

D_t = mean(D_t,1);

Dtvals = dt*R0;

figure
h1 = loglog(Dtvals,D_t,'ro-'); hold on
set(h1,'linewidth',1)
hold on
h3 = loglog(Dtvals,Dtvals,'b--');
% loglog(Dtvals,Dtvals.^0.5,'r--');
xlabel('h','Fontsize',8)
set(h2,'linewidth',1)
set(gca,'Fontsize',8)
title('MS errors','Fontsize',12)
legend('TM method','line of slope 1')