% global a b d gamma mu
a = -0.6; b = -1; c = 0.3;
d = -0.5; gamma = 1; mu = 2;
h = 0.001; T = 200; t = 0:h:T;

y_0 = [2.0;0.9;1.5];
y0 = log([2.0;0.9;1.5]);

N = length(t); M = 1;

y_mid = zeros(3,N,M); y_mid(:,1,:) = repmat(y0,1,M);

y_Mid = zeros(3,N,M); y_Mid(:,1,:) = repmat(y_0,1,M);

normal = randn(N-1,M);
W = sqrt(h)*normal;
Ah = sqrt(4*abs(log(h)));
normal(normal>Ah) = Ah; normal(normal<-Ah) = -Ah;
dW_hat = sqrt(h)*normal;

PStr = zeros(N-1,1);

for j = 1:M
for i = 1:N-1
    stepsize = h + c*dW_hat(i,j);
    
    y1 = y_mid(:,i,j)+10; 
    y2 = y_mid(:,i,j)*(1+h); 
    
    y3 = y_Mid(:,i,j)+10; 
    y4 = y_Mid(:,i,j)*(1+h);
    
    while norm(y1-y2)>1e-8 && norm(y3-y4)>1e-8 % || norm(y5-y6)>1e-5
        y1 = y2;
        y = y1;
        x = y_mid(:,i,j);
        BH = [d*(gamma + exp(x(2)/2 + y(2)/2)) - b*d*(mu + a*exp(x(3)/2 + y(3)/2));
             mu + a*exp(x(3)/2 + y(3)/2) - a*b*d*exp(x(1)/2 + y(1)/2);
             - a*d*exp(x(1)/2 + y(1)/2)*b^2 + gamma + exp(x(2)/2 + y(2)/2)];
        y2 = x + stepsize*BH;
        
        y3 = y4;
        y = y3;
        x = y_Mid(:,i,j);
        BH = [d*(y(1)+x(1))/2*(gamma + (y(2)+x(2))/2) - b*d*(y(1)+x(1))/2*(a*(y(3)+x(3))/2 + mu)
             (y(2)+x(2))/2*((y(3)+x(3))/2*a + mu) - a*b*d*(y(1)+x(1))*(y(2)+x(2))/4
             - a*d*(y(1)+x(1))*(y(3)+x(3))*b^2/4 + (y(3)+x(3))/2*(gamma + (y(2)+x(2))/2)];
        y4 = x + stepsize*BH;
    end
    y_mid(:,i+1,j) = y2;
    
    y_Mid(:,i+1,j) = y4;
    PStr(i) = PoissonStr(y_mid(:,i,j),y_mid(:,i+1,j),stepsize);
end
end

C1 = -1/d*y_mid(1,:,1) - b*y_mid(2,:,1) + y_mid(3,:,1);
plot(t(2:end),PStr)
ylim([0,5E-16])
Y = exp(y_mid);

figure
subplot(311)
plot(t,Y(1,:,1),'r--',t,y_Mid(1,:,1),'b--')
xlim([0,30])
ylim([0,15])
ylabel('y^1')

subplot(312)
plot(t,Y(2,:,1),'r--',t,y_Mid(2,:,1),'b--')
xlim([0,30])
ylim([0,2])
ylabel('y^2')

subplot(313)
plot(t,Y(3,:,1),'r--',t,y_Mid(3,:,1),'b--')
ylabel('y^3')
xlim([0,30])
ylim([0,20])

xlabel('t')
% ylim([0,5])
legend('TM method','Midpoint method')

figure

C_Mid = -log(y_Mid(1,:,1))/d - b*log(y_Mid(2,:,1)) + log(y_Mid(3,:,1));
C_Y = -log(Y(1,:,1))/d - b*log(Y(2,:,1)) + log(Y(3,:,1));

H_Mid = Hamiltonian(y_Mid(:,:,1),a,b,gamma,mu);
H_Y = Hamiltonian(Y(:,:,1),a,b,gamma,mu);

plot(t,C_Y,'r','LineWidth',1)
hold on
plot(t,C_Mid,'b','LineWidth',1)
title('Carsimir')
xlabel('t')
% xlim([0,200])
ylim([1.6,1.7])
legend('TM method','Midpoint method')

figure
plot(t,H_Y,'r','LineWidth',1)
hold on
plot(t,H_Mid,'b','LineWidth',1)
xlabel('t')
title('Hamiltonian')
ylim([1.95,2.10])
legend('TM method','Midpoint method')
% H_Mid = Hamiltonian(y_Mid,a,b,gamma,mu);
% C_IP = -log(y_IP(1,:,1))/d - b*log(y_IP(2,:,1)) + log(y_IP(3,:,1));
% C_EP = -log(y_Mid(1,:,1))/d - b*log(y_Mid(2,:,1)) + log(y_Mid(3,:,1));